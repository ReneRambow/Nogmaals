i = 0
t = 50

while i < 1000:
    i += t
    t += 1
    print(i)