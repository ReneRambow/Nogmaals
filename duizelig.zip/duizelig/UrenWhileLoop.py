print("AM Hours\n")
i = 0
while i < 12:
    i += 1
    print(str(i) + 'AM\n')
print("PM Hours\n")
x = 0
while x < 12:
    x += 1
    print(str(x) + 'PM\n')