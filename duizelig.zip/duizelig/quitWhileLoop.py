while input('Zeg Quit!\n') != 'Quit'.lower():
    print('Zeg Quit')

print("Je hebt Quit gezegd")