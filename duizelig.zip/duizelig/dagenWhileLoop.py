dagen = input("welke dag van de week wilt u weten?\n ma, di, wo, do, vr, za, zo \n")
if dagen == "ma":
    print("Maandag")

if dagen == 'di':
    print("Maandag, Dinsdag")

if dagen == 'wo':
    print("Maandag, Dinsdag, Woensdag")

if dagen == 'do':
    print("Maandag, Dinsdag, Woensdag. Donderdag")

if dagen == 'vr':
    print("Maandag, Dinsdag, Woensdag, Donderdag, Vrijdag")

if dagen == 'za':
    print("Maandag, Dinsdag, Woensdag, Donderdag, Vrijdag, Zaterdag")

if dagen == 'zo':
    print("Maandag, Dinsdag, Woensdag, Donderdag, Vrijdag, Zaterdag, Zondag")